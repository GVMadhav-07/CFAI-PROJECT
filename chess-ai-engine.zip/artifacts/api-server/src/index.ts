import { spawn } from "child_process";
import { dirname, join } from "path";
import { fileURLToPath } from "url";

const port = process.env["PORT"] ?? "8080";
const __filename = fileURLToPath(import.meta.url);
const __dir = dirname(__filename);
// app.py lives one level up from dist/ → artifacts/api-server/app.py
const appPath = join(__dir, "..", "app.py");

const proc = spawn(
  "streamlit",
  [
    "run",
    appPath,
    "--server.port",
    port,
    "--server.address",
    "0.0.0.0",
    "--server.headless",
    "true",
    "--server.enableCORS=false",
    "--server.enableWebsocketCompression=false",
  ],
  { stdio: "inherit" },
);

proc.on("error", (err: Error) => {
  console.error("Failed to start streamlit:", err);
  process.exit(1);
});

proc.on("exit", (code: number | null) => {
  process.exit(code ?? 0);
});
